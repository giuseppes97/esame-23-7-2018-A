package it.polito.tdp.newufosightings.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

import org.jgrapht.Graphs;
import org.jgrapht.graph.DefaultWeightedEdge;
import org.jgrapht.graph.SimpleWeightedGraph;

import it.polito.tdp.newufosightings.db.NewUfoSightingsDAO;
import it.polito.tdp.newufosightings.model.Evento.TipoEvento;

public class Simulatore {
	private PriorityQueue<Evento> queue = new PriorityQueue<>() ;
	private NewUfoSightingsDAO dao=new NewUfoSightingsDAO();
	SimpleWeightedGraph<State,DefaultWeightedEdge> grafooo;
	//stato del mondo
	private List<State> tuttistati;
	private Map<String,State> mappastati;
	private List<Sighting> tuttiavvistamenti;
	private int TIMEOUT_ALLERTA;
	private int PROB;
	
	
	public Simulatore(int giorni, int prob, int annoavv, String forma,SimpleWeightedGraph g) {
		grafooo=g;
		tuttistati=new ArrayList<State>(dao.loadAllStates());
		mappastati=new HashMap<String,State>();
		for(State s:tuttistati) {
			mappastati.put(s.getId(), s);
		}
		System.out.println(mappastati);
		System.out.println("la dimensione della mappa �: "+mappastati.size());
		tuttiavvistamenti=new ArrayList<Sighting>(dao.loadAllSightings(annoavv,forma));
		TIMEOUT_ALLERTA=giorni;
		PROB=prob;
	}
	
	public void init() {
		
		for(Sighting s:tuttiavvistamenti) {
			System.out.println(""+mappastati.get(s.getState().toUpperCase()));
			
			queue.add(  new Evento(s.getDatetime(),TipoEvento.AVVISTAMENTO,mappastati.get(s.getState().toUpperCase())))   ;
		}
	}
	public String run() {

		while (!queue.isEmpty()) {
			Evento ev = queue.poll();
		    State s=ev.getStato();
		    
		    
	
		switch (ev.getTipo()) {
		
		case AVVISTAMENTO:
			s.setAllerta(s.getAllerta()-1);
			if(s.getAllerta()<1) { s.setAllerta(1);}
			queue.add(new Evento(ev.getData().plusDays(TIMEOUT_ALLERTA),TipoEvento.TIMEOUT,s));
			double a=Math.random()*100;
			if(a<=PROB) {
				queue.add(new Evento(ev.getData(),TipoEvento.ALLERTA_CAUSA_VICINO,s));
				}
			
			break;
		case TIMEOUT:
		 s.setAllerta(s.getAllerta()+1);
		 if (s.getAllerta()>5) s.setAllerta(5);
			break;
			
			
		case ALLERTA_CAUSA_VICINO:
			for(State sta:Graphs.neighborListOf(grafooo, s)) {
				sta.setAllerta(sta.getAllerta()-0.5);
				if(sta.getAllerta()<1) sta.setAllerta(1);
				queue.add(new Evento(ev.getData().plusDays(TIMEOUT_ALLERTA),TipoEvento.TIMEOUT_CAUSA_VICINO,s));
		
		}
			break;
		case TIMEOUT_CAUSA_VICINO:
			s.setAllerta(s.getAllerta()+0.5);
			if (s.getAllerta()>5) s.setAllerta(5);
			break;
	
}
		
		
}
	String stringa="Risultati dell'allerta dopo la simulazione: \n";
	for(State s:mappastati.values()) {
		stringa=stringa+""+s.getId()+" "+s.getAllerta()+"\n";
	}
		return stringa;		
}
}