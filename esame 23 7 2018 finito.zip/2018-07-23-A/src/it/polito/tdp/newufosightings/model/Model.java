package it.polito.tdp.newufosightings.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.jgrapht.Graphs;
import org.jgrapht.graph.DefaultWeightedEdge;
import org.jgrapht.graph.SimpleWeightedGraph;

import it.polito.tdp.newufosightings.db.NewUfoSightingsDAO;

public class Model {
NewUfoSightingsDAO dao;
SimpleWeightedGraph<State,DefaultWeightedEdge> grafo;
public Model() {
	dao=new NewUfoSightingsDAO();
	grafo=new SimpleWeightedGraph<>(DefaultWeightedEdge.class);
}
	public Collection<String> gettutteformeanno(int anno) {
	
		return dao.tutteleforme(anno);
	}
	public void creagrafo(int anno, String forma) {
		
		List<State> listastati=new ArrayList<State>();
		listastati.addAll(dao.loadAllStates());
		Graphs.addAllVertices(grafo, listastati);
		System.out.println("grafo creato n vertici: "+grafo.vertexSet().size());
		for(State s:grafo.vertexSet()) {
			//System.out.println("Entrato 1");
		
			for(State st:grafo.vertexSet()) {
				//System.out.println("entrato2");
				
				if(s.equals(st)) {}
				else {
					if(dao.sonoconfinanti(s,st)) {
						//System.out.println("entrato3");
						
						int count=0;
						count=dao.getnumeroconforma(anno,forma,s);
						//System.out.println("entrato4");
						
						count=count+dao.getnumeroconforma(anno,forma,st);
						//System.out.println("entrato5");
						
						Graphs.addEdge(grafo, s, st, count);
						DefaultWeightedEdge e=grafo.getEdge(s, st);
						//System.out.println("entrato6");
						System.out.println(""+grafo.getEdgeWeight(e));
					
						
					}
				}
			}
		}
		System.out.println(grafo.edgeSet().size());
		System.out.println(grafo);
		
	}
	public String gettuttistaticonpeso() {
		String stringa="";
		for(State s:grafo.vertexSet()) {
			stringa=stringa+"stato "+s.getName()+": ";
			List<State> adiacenti=new ArrayList<>(Graphs.neighborListOf(grafo, s));
			int i=0;
			for(State st:adiacenti) {
				DefaultWeightedEdge e=grafo.getEdge(s, st);
				i=(int)(i+grafo.getEdgeWeight(e));
			}
			stringa=stringa+""+i+"\n";
			
		}
		return stringa;
	}
	public String failasimulazione(int giorni, int alfa,int anno,String forma) {
		Simulatore s=new Simulatore(giorni,alfa,anno,forma,grafo);
		s.init();
		return s.run();
		
	}

}
