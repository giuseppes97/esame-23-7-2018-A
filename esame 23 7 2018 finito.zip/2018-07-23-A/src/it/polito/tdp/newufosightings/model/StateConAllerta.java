package it.polito.tdp.newufosightings.model;

public class StateConAllerta {
	private String id;
	private String name;
	private String capital;
	private Double lat;
	private Double lng;
	private int area;
	private int population;
	private String neighbors;
	private double allerta;
	
	public StateConAllerta(String id, String name, String capital, Double lat, Double lng, int area, int population,
			String neighbors) {
		super();
		this.id = id;
		this.name = name;
		this.capital = capital;
		this.lat = lat;
		this.lng = lng;
		this.area = area;
		this.population = population;
		this.neighbors = neighbors;
		allerta=5;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCapital() {
		return capital;
	}
	public void setCapital(String capital) {
		this.capital = capital;
	}
	public Double getLat() {
		return lat;
	}
	public void setLat(Double lat) {
		this.lat = lat;
	}
	public Double getLng() {
		return lng;
	}
	public void setLng(Double lng) {
		this.lng = lng;
	}
	public int getArea() {
		return area;
	}
	public void setArea(int area) {
		this.area = area;
	}
	public int getPopulation() {
		return population;
	}
	public void setPopulation(int population) {
		this.population = population;
	}
	public String getNeighbors() {
		return neighbors;
	}
	public void setNeighbors(String neighbors) {
		this.neighbors = neighbors;
	}
	public double getAllerta() {
		return allerta;
	}
	public void setAllerta(double allerta) {
		this.allerta = allerta;
	}
	
}
