package it.polito.tdp.newufosightings.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Evento implements Comparable<Evento>{

	public enum TipoEvento{
		AVVISTAMENTO,
		ALLERTA_CAUSA_VICINO,
		TIMEOUT_CAUSA_VICINO,
		TIMEOUT
	}
	private LocalDateTime data;
	private TipoEvento tipo;
	private State stato;
	public Evento(LocalDateTime data, TipoEvento tipo,State s) {
		super();
		this.data = data;
		this.tipo = tipo;
		stato=s;
	}
	public LocalDateTime getData() {
		return data;
	}
	public void setData(LocalDateTime data) {
		this.data = data;
	}
	public TipoEvento getTipo() {
		return tipo;
	}
	public void setTipo(TipoEvento tipo) {
		this.tipo = tipo;
	}
	@Override
	public int compareTo(Evento ev) {
	
		return this.data.compareTo(ev.getData());
	}
	public State getStato() {
		return stato;
	}
	public void setStato(State stato) {
		this.stato = stato;
	}
	
}
